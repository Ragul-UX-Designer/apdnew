/* =====================================================================
   TEMPLE WAVES · shared shell (header + footer)
   The header/footer markup lives here as strings and is injected into the
   #site-header / #site-footer placeholders on every page — no partials
   folder, no fetch (so it also works when opened directly as a file).
   ===================================================================== */
(function () {
  'use strict';

  var header =
  '<div class="topbar">' +
    '<div class="container topbar-wrapper">' +
      '<div class="topbar__left">' +
        '<a href="mailto:contact@amarprakash.in"><i class="fa fa-envelope"></i> contact@amarprakash.in</a>' +
      '</div>' +
      '<div class="topbar__right">' +
        '<a href="tel:04440005000"><i class="fa fa-phone"></i> 044 4000 5000</a>' +
      '</div>' +
    '</div>' +
  '</div>' +
  '<header class="nav" id="nav">' +
    '<div class="container nav-wrapper">' +
      '<div class="nav__brand-wrapper">' +
        '<a class="nav__brand" href="index.html" aria-label="Temple Waves home">' +
          '<img src="assets/img/new-logo.png" alt="Temple Waves by Amarprakash">' +
        '</a>' +
      '</div>' +
      '<nav class="nav__links" id="navLinks" aria-label="Primary">' +
        '<a href="index.html" data-nav="home">Home</a>' +
        '<a href="amenities.html" data-nav="amenities">Amenities</a>' +
        '<a href="walkthrough.html" data-nav="walkthrough">Walkthrough</a>' +
        '<a href="gallery.html" data-nav="gallery">Views</a>' +
        '<a href="floor-plans.html" data-nav="plans">Plans</a>' +
        '<a href="testimonials.html" data-nav="testimonials">Testimonials</a>' +
        '<a href="contact.html" class="nav__mobile-cta">Book a Site Visit</a>' +
      '</nav>' +
      '<div class="nav__cta">' +
        '<a href="contact.html" class="btn btn--register">Book a Site Visit</a>' +
        '<button class="nav__toggle" id="navToggle" aria-label="Menu" aria-expanded="false"><span></span></button>' +
      '</div>' +
    '</div>' +
  '</header>';

  var footer =
  '<footer class="footer">' +
    '<div class="container">' +
      '<div class="footer__grid">' +
        '<div class="footer__brand">' +
          '<a href="https://www.amarprakash.in/" target="_blank" rel="noopener"><img src="assets/img/Amarprakash-Logo.png" alt="Amarprakash"></a>' +
          '<p style="color:#c7b2e6; margin-bottom: 20px;">Tamilnadu\'s most trusted developer, building quality homes across Chennai since 2004.</p>' +
          '<p style="color:#c7b2e6; margin-bottom: 24px;">Happiness lives here.</p>' +
          '<div class="footer__certs">' +
            '<img src="assets/img/credai_logo.jpg" alt="CREDAI">' +
            '<img src="assets/img/igbc_logo.jpg" alt="IGBC">' +
            '<img src="assets/img/bai_logo.jpg" alt="BAI">' +
            '<img src="assets/img/tuv_logo.jpg" alt="TUV SUD">' +
          '</div>' +
        '</div>' +
        '<div>' +
          '<h4>Explore</h4>' +
          '<div class="footer__links">' +
            '<a href="index.html">Home</a>' +
            '<a href="amenities.html">Amenities</a>' +
            '<a href="walkthrough.html">Walkthrough</a>' +
            '<a href="gallery.html">Views</a>' +
            '<a href="floor-plans.html">Plans</a>' +
            '<a href="testimonials.html">Testimonials</a>' +
            '<a href="../e-brouchre.pdf" target="_blank" rel="noopener">E-Brochure</a>' +
          '</div>' +
        '</div>' +
        '<div>' +
          '<h4>Quick Links</h4>' +
          '<div class="footer__links">' +
            '<a href="http://www.amarprakash.in/palmriviera/" target="_blank" rel="noopener">Venezian - Palm Riviera</a>' +
            '<a href="http://www.amarprakash.in/royal_castle/" target="_blank" rel="noopener">The Royal Castle</a>' +
            '<a href="http://www.amarprakash.in/suncity/" target="_blank" rel="noopener">Suncity</a>' +
            '<a href="https://www.amarprakash.in/customer-reviews/mavn-amar-prakash-chennai-reviews.html" target="_blank" rel="noopener">Amarprakash Chennai Reviews</a>' +
            '<a href="index.html">Chennai Flats</a>' +
            '<a href="budget-flats-in-chennai-for-sale.html">Budget Flats in Chennai</a>' +
          '</div>' +
        '</div>' +
        '<div>' +
          '<h4>Get in touch</h4>' +
          '<ul class="footer__contact">' +
            '<li><i class="fa fa-map-marker"></i><span>Temple Waves,<br>Kundrathur, Chennai</span></li>' +
            '<li><i class="fa fa-phone"></i><a href="tel:04440005000">044 4000 5000</a></li>' +
            '<li><i class="fa fa-envelope"></i><a href="mailto:contact@amarprakash.in">contact@amarprakash.in</a></li>' +
            '<li style="margin-top: 24px;">' +
              '<div class="footer__social">' +
                '<a href="https://www.instagram.com/amarprakash_developers/" target="_blank" rel="noopener" aria-label="Instagram"><i class="fa fa-instagram"></i></a>' +
                '<a href="https://www.facebook.com/AmarprakashDevelopers/" target="_blank" rel="noopener" aria-label="Facebook"><i class="fa fa-facebook"></i></a>' +
                '<a href="https://www.youtube.com/@amarprakashdeveloperspvtltd" target="_blank" rel="noopener" aria-label="YouTube"><i class="fa fa-youtube-play"></i></a>' +
              '</div>' +
            '</li>' +
          '</ul>' +
        '</div>' +
      '</div>' +
      '<div class="footer__bottom">' +
        '<span>&copy; <span id="year">2026</span> <a href="https://www.amarprakash.in/" target="_blank" rel="noopener" style="color: inherit;">Amarprakash Developers Pvt Ltd</a>. All rights reserved.</span>' +
        '<div class="footer__legal">' +
          '<a href="policy.html">Privacy Policy</a>' +
          '<a href="disclaimer.html">Disclaimer</a>' +
          '<a href="feedback.html">Feedback</a>' +
        '</div>' +
      '</div>' +
    '</div>' +
  '</footer>' +
  '<div class="fab">' +
    '<a class="wa" href="https://wa.me/918925847361" target="_blank" rel="noopener" aria-label="WhatsApp"><i class="fa fa-whatsapp"></i></a>' +
    '<button class="top" id="fabTop" onclick="window.scrollTo({top:0,behavior:\'smooth\'})" aria-label="Back to top"><i class="fa fa-arrow-up"></i></button>' +
  '</div>' +
  '<div class="lb" id="lightbox" aria-hidden="true">' +
    '<div class="lb__inner">' +
      '<button class="lb__close" data-close aria-label="Close"><i class="fa fa-times"></i></button>' +
      '<button class="lb__nav lb__nav--prev" id="lbPrev" aria-label="Previous"><i class="fa fa-angle-left"></i></button>' +
      '<button class="lb__nav lb__nav--next" id="lbNext" aria-label="Next"><i class="fa fa-angle-right"></i></button>' +
      '<img id="lbImg" src="" alt="">' +
      '<p class="lb__cap" id="lbCap"></p>' +
    '</div>' +
  '</div>' +
  '<div class="lb" id="videoLb" aria-hidden="true">' +
    '<div class="lb__video">' +
      '<button class="lb__close" data-close aria-label="Close video" style="z-index:4"><i class="fa fa-times"></i></button>' +
      '<div id="lbVideoHost" style="width:100%;height:100%"></div>' +
    '</div>' +
  '</div>' +
  '<div class="lb planlb" id="planLb" aria-hidden="true">' +
    '<div class="planlb__box">' +
      '<button class="lb__close" data-close aria-label="Close" style="top:14px;right:14px"><i class="fa fa-times"></i></button>' +
      '<div class="planlb__head"><h3 id="planTitle">Plans</h3><span class="planlb__label" id="planLabel"></span></div>' +
      '<div class="planlb__stage">' +
        '<button class="planlb__arrow prev" id="planPrev" aria-label="Previous plan"><i class="fa fa-chevron-left"></i></button>' +
        '<img id="planImg" src="" alt="">' +
        '<button class="planlb__arrow next" id="planNext" aria-label="Next plan"><i class="fa fa-chevron-right"></i></button>' +
      '</div>' +
      '<div class="planlb__foot">' +
        '<span class="planlb__count" id="planCount"></span>' +
        '<a class="btn btn--ghost" id="planDownload" href="#" target="_blank" rel="noopener"><i class="fa fa-search-plus"></i> Open full size</a>' +
      '</div>' +
      '<div class="planlb__thumbs" id="planThumbs"></div>' +
    '</div>' +
  '</div>';

  function boot() {
    var h = document.getElementById('site-header');
    if (h) h.outerHTML = header;
    var f = document.getElementById('site-footer');
    if (f) f.outerHTML = footer;

    var page = document.body.getAttribute('data-page');
    var links = document.querySelectorAll('#navLinks a[data-nav]');
    for (var i = 0; i < links.length; i++) {
      if (links[i].getAttribute('data-nav') === page) links[i].classList.add('active');
    }

    var s = document.createElement('script');
    s.src = 'assets/js/main.js';
    document.body.appendChild(s);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
