/* =====================================================================
   TEMPLE WAVES · 2026 Redesign — interactions
   Vanilla JS, no dependencies. Progressive & accessible.
   ===================================================================== */
(function () {
  'use strict';
  const $  = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];

  /* ---------- 1. Sticky nav shadow ---------------------------------- */
  const nav = $('#nav');
  const onScroll = () => {
    if (nav) nav.classList.toggle('is-stuck', window.scrollY > 24);
    const fabTop = $('#fabTop');
    if (fabTop) fabTop.classList.toggle('show', window.scrollY > 500);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- 2. Mobile menu --------------------------------------- */
  const toggle = $('#navToggle');
  const links  = $('#navLinks');
  if (toggle && links) {
    toggle.addEventListener('click', () => {
      const open = links.classList.toggle('open');
      document.body.classList.toggle('menu-open', open);
      toggle.setAttribute('aria-expanded', open);
    });
    $$('#navLinks a').forEach(a => a.addEventListener('click', () => {
      links.classList.remove('open');
      document.body.classList.remove('menu-open');
    }));
  }

  /* ---------- 3. Scrollspy (active link) --------------------------- */
  const sections = $$('section[id]');
  const navMap = new Map($$('#navLinks a[href^="#"]').map(a => [a.getAttribute('href').slice(1), a]));
  const spy = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        navMap.forEach(a => a.classList.remove('active'));
        const a = navMap.get(e.target.id);
        if (a) a.classList.add('active');
      }
    });
  }, { rootMargin: '-45% 0px -50% 0px' });
  sections.forEach(s => spy.observe(s));

  /* ---------- 4. Scroll reveal ------------------------------------- */
  const revealer = new IntersectionObserver((entries, obs) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('in'); obs.unobserve(e.target); }
    });
  }, { threshold: 0.12 });
  $$('.reveal').forEach(el => revealer.observe(el));

  /* ---------- 5. Hero parallax ------------------------------------- */
  const parallax = $$('[data-parallax]');
  if (parallax.length && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    window.addEventListener('scroll', () => {
      const y = window.scrollY;
      parallax.forEach(el => {
        const speed = parseFloat(el.dataset.parallax) || 0.15;
        el.style.transform = `translateY(${y * speed}px)`;
      });
    }, { passive: true });
  }

  /* ---------- 5b. Hero project-views slider ------------------------ */
  const heroSlider = $('#heroSlider');
  if (heroSlider) {
    const slides = $$('.hero__slide', heroSlider);
    const dots = $$('#heroDots button');
    const caption = $('#heroCaption');
    const captionText = caption ? $('span', caption) : null;
    let hi = 0, htimer = null;
    const goHero = (i) => {
      hi = (i + slides.length) % slides.length;
      slides.forEach((s, j) => s.classList.toggle('is-active', j === hi));
      dots.forEach((d, j) => d.classList.toggle('active', j === hi));
      if (captionText) {
        caption.style.opacity = '0';
        setTimeout(() => {
          captionText.textContent = slides[hi].dataset.cap || slides[hi].alt || '';
          caption.style.opacity = '1';
        }, 220);
      }
    };
    const startHero = () => { htimer = setInterval(() => goHero(hi + 1), 4200); };
    const resetHero = () => { clearInterval(htimer); startHero(); };
    dots.forEach((d, j) => d.addEventListener('click', () => { goHero(j); resetHero(); }));
    heroSlider.addEventListener('mouseenter', () => clearInterval(htimer));
    heroSlider.addEventListener('mouseleave', resetHero);
    if (slides.length > 1 && !matchMedia('(prefers-reduced-motion: reduce)').matches) startHero();
  }

  /* ---------- 6. Animated counters --------------------------------- */
  const counters = $$('[data-count]');
  const countObs = new IntersectionObserver((entries, obs) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el = e.target;
      const target = parseFloat(el.dataset.count);
      const suffix = el.dataset.suffix || '';
      const dur = 1500; const t0 = performance.now();
      const tick = (now) => {
        const p = Math.min((now - t0) / dur, 1);
        const val = target * (1 - Math.pow(1 - p, 3));
        el.textContent = (Number.isInteger(target) ? Math.round(val) : val.toFixed(1)) + suffix;
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      obs.unobserve(el);
    });
  }, { threshold: 0.6 });
  counters.forEach(c => countObs.observe(c));

  /* ---------- 7. Amenity tabs -------------------------------------- */
  $$('.amn__tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const id = tab.dataset.tab;
      $$('.amn__tab').forEach(t => t.classList.toggle('active', t === tab));
      $$('.amn__panel').forEach(p => p.classList.toggle('active', p.id === id));
    });
  });

  /* ---------- 8. Testimonials carousel ----------------------------- */
  const track = $('#testiTrack');
  if (track) {
    const cards = $$('.testi__card', track);
    let index = 0;
    const perView = () => window.innerWidth <= 680 ? 1 : window.innerWidth <= 1080 ? 2 : 3;
    const max = () => Math.max(0, cards.length - perView());
    const go = (i) => {
      index = Math.max(0, Math.min(i, max()));
      const card = cards[0].getBoundingClientRect().width;
      const gap = 24;
      track.style.transform = `translateX(${-(card + gap) * index}px)`;
    };
    $('#testiPrev').addEventListener('click', () => go(index - 1));
    $('#testiNext').addEventListener('click', () => go(index + 1));
    let auto = setInterval(() => go(index >= max() ? 0 : index + 1), 5000);
    track.closest('.testi').addEventListener('mouseenter', () => clearInterval(auto));
    window.addEventListener('resize', () => go(index));
  }

  /* ---------- 9. Image lightbox (gallery) --------------------------- */
  const lb = $('#lightbox');
  const lbImg = $('#lbImg');
  const lbCap = $('#lbCap');
  const lbImages = $$('[data-lb]');
  let lbIndex = 0;
  
  const showLbImg = (idx) => {
    if (!lbImages.length) return;
    lbIndex = (idx + lbImages.length) % lbImages.length;
    const el = lbImages[lbIndex];
    lbImg.src = el.dataset.lb;
    lbCap.textContent = el.dataset.cap || '';
  };

  lbImages.forEach((el, idx) => {
    el.addEventListener('click', () => {
      showLbImg(idx);
      lb.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  const lbPrev = $('#lbPrev');
  const lbNext = $('#lbNext');
  if (lbPrev) lbPrev.addEventListener('click', (e) => { e.stopPropagation(); showLbImg(lbIndex - 1); });
  if (lbNext) lbNext.addEventListener('click', (e) => { e.stopPropagation(); showLbImg(lbIndex + 1); });
  
  document.addEventListener('keydown', e => {
    if (!lb.classList.contains('open')) return;
    if (e.key === 'ArrowLeft') showLbImg(lbIndex - 1);
    if (e.key === 'ArrowRight') showLbImg(lbIndex + 1);
  });

  // Hero caption → open the currently active slide in the lightbox
  const heroCap = $('#heroCaption');
  if (heroCap) {
    heroCap.addEventListener('click', () => {
      const active = $('.hero__slide.is-active');
      if (!active) return;
      lbImg.src = active.src;
      lbCap.textContent = active.dataset.cap || active.alt || '';
      lb.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  }

  /* ---------- 10. Video lightbox (YouTube) -------------------------- */
  const vlb = $('#videoLb');
  const vHost = $('#lbVideoHost');
  const YT = 'https://www.youtube.com/embed/-_exiPXKyx4?autoplay=1&rel=0';
  $$('[data-video]').forEach(el => {
    el.addEventListener('click', () => {
      vHost.innerHTML = `<iframe src="${YT}" title="Temple Waves Master Walkthrough" allow="autoplay; encrypted-media; fullscreen" allowfullscreen></iframe>`;
      vlb.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  /* ---------- 10b. Floor-plan viewer -------------------------------- */
  const planLb = $('#planLb');
  if (planLb) {
    const PB = 'assets/img/floorplan/';
    const P = {
      '1bhk': [
        [1, 'Type 2 · 1 BHK · East facing'], [11, 'Unit 5 · 1 BHK · South facing'],
        [12, 'Unit 5A · 1 BHK · West facing'], [13, 'Unit 6 · 1 BHK · North facing'],
        [14, 'Unit 6B · 1 BHK · North facing']
      ],
      '2bhk': [
        [2, 'Type 3 · 2 BHK · East facing'], [4, 'Type 6 · 2 BHK · East facing'],
        [9, 'Type 11 · 2 BHK · West facing'], [10, 'Type 12 · 2 BHK (L) · West facing'],
        [15, 'Unit 7 · 2 BHK · East facing'], [16, 'Unit 8 · 2 BHK · West facing'],
        [17, 'Unit 8A · 2 BHK · West facing'], [18, 'Unit 9 · 2 BHK · East facing'],
        [19, 'Unit 10 · 2 BHK · North facing'], [20, 'Unit 11 · 2 BHK · North facing'],
        [21, 'Unit 11A · 2 BHK · South facing'], [22, 'Unit 12 · 2 BHK (L) · North facing'],
        [23, 'Unit 13 · 2 BHK (L) · North facing'], [24, 'Unit 13T · 2 BHK (L) · North facing'],
        [25, 'Unit 14 · 2 BHK (L) · South facing'], [26, 'Unit 15 · 2 BHK (L) · East facing'],
        [27, 'Unit 15A · 2 BHK (L) · East facing'], [28, 'Unit 16 · 2 BHK (L) · West facing'],
        [29, 'Unit 16T · 2 BHK (L) · West facing'], [33, 'Unit E1 · 2 BHK · East facing'],
        [34, 'Unit E2 · 2 BHK · East facing'], [35, 'Unit E3 · 2 BHK · West facing'],
        [36, 'Unit E4 · 2 BHK · North facing']
      ],
      '3bhk': [
        [3, 'Type 5 · 3 BHK · East facing'], [5, 'Type 7 · 3 BHK · South facing'],
        [6, 'Type 8 · 3 BHK · North facing'], [7, 'Type 9 · 3 BHK · East facing'],
        [8, 'Type 10 · 3 BHK · North facing'], [30, 'Unit 17A · 3 BHK · North facing'],
        [31, 'Unit 18 · 3 BHK · East facing'], [32, 'Unit 19 · 3 BHK · South facing']
      ]
    };
    P.all = [...P['1bhk'], ...P['2bhk'], ...P['3bhk']];
    const titles = { '1bhk': '1 BHK Floor Plans', '2bhk': '2 BHK Floor Plans', '3bhk': '3 BHK Floor Plans', all: 'All Floor Plans' };

    const pImg = $('#planImg'), pLabel = $('#planLabel'), pTitle = $('#planTitle'),
          pThumbs = $('#planThumbs'), pCount = $('#planCount'), pDl = $('#planDownload');
    let cur = [], idx = 0;

    const show = (i) => {
      if (!cur.length) return;
      idx = (i + cur.length) % cur.length;
      const [n, label] = cur[idx];
      pImg.src = PB + n + '.jpg'; pImg.alt = label;
      pLabel.textContent = label;
      pDl.href = PB + n + '.jpg';
      pCount.textContent = (idx + 1) + ' / ' + cur.length;
      $$('img', pThumbs).forEach((t, j) => t.classList.toggle('active', j === idx));
      const act = $('img.active', pThumbs);
      if (act) act.scrollIntoView({ inline: 'center', block: 'nearest' });
    };
    const openPlans = (type) => {
      cur = P[type] || P.all;
      pTitle.textContent = titles[type] || titles.all;
      pThumbs.innerHTML = cur.map(([n, label], j) =>
        `<img src="${PB + n}s.jpg" data-i="${j}" alt="${label}" loading="lazy">`).join('');
      $$('img', pThumbs).forEach(t => t.addEventListener('click', () => show(+t.dataset.i)));
      show(0);
      planLb.classList.add('open');
      document.body.style.overflow = 'hidden';
    };
    $$('[data-plan-open]').forEach(b => b.addEventListener('click', () => openPlans(b.dataset.planOpen)));
    // Shareable deep link, e.g. ?viewplans=2bhk
    const deep = new URLSearchParams(location.search).get('viewplans');
    if (deep && (P[deep] || deep === 'all')) openPlans(deep);
    $('#planPrev').addEventListener('click', () => show(idx - 1));
    $('#planNext').addEventListener('click', () => show(idx + 1));
    document.addEventListener('keydown', e => {
      if (!planLb.classList.contains('open')) return;
      if (e.key === 'ArrowLeft') show(idx - 1);
      if (e.key === 'ArrowRight') show(idx + 1);
    });
  }

  const closeAll = () => {
    lb.classList.remove('open');
    vlb.classList.remove('open');
    if (planLb) planLb.classList.remove('open');
    vHost.innerHTML = '';        // stop the video
    document.body.style.overflow = '';
  };
  $$('[data-close]').forEach(b => b.addEventListener('click', closeAll));
  [lb, vlb, planLb].filter(Boolean).forEach(box => box.addEventListener('click', e => { if (e.target === box) closeAll(); }));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeAll(); });

  /* ---------- 11. Enquiry form (client-side, inline per-field errors) -------- */
  const form = $('#enquiryForm');
  if (form) {
    const emailRE = /^([a-zA-Z0-9_.\-])+@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    const phoneRE = /^((\+)?[1-9]{1,2})?([-\s.])?((\(\d{1,4}\))|\d{1,4})(([-\s.])?[0-9]{1,12}){1,2}$/;
    const f = form.elements;
    const formLoadedAt = Date.now();   // anti-spam time-trap reference

    const fieldOf = el => el && el.closest('.field');
    const clearErr = el => { const fl = fieldOf(el); if (fl) fl.classList.remove('invalid'); };
    const showErr  = (el, msg) => {
      const fl = fieldOf(el); if (!fl) return;
      fl.classList.add('invalid');
      const box = fl.querySelector('.field__err'); if (box) box.textContent = msg;
    };

    // Clear a field's error the moment the user starts fixing it.
    form.querySelectorAll('input, select, textarea').forEach(el => {
      el.addEventListener('input',  () => clearErr(el));
      el.addEventListener('change', () => clearErr(el));
    });

    // Prevent picking a past visit date in the native picker.
    if (f.visit_date) {
      const t = new Date();
      const todayStr = t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-' + String(t.getDate()).padStart(2, '0');
      f.visit_date.addEventListener('focus', () => { f.visit_date.min = todayStr; });
    }

    function validate() {
      let firstBad = null;
      const fail = (el, msg) => { showErr(el, msg); if (!firstBad) firstBad = el; };
      form.querySelectorAll('.field').forEach(fl => fl.classList.remove('invalid'));

      if (!f.name.value.trim())                       fail(f.name, 'Please enter your name');

      // Email is optional — only validate the format when something was typed.
      if (f.email.value.trim() && !emailRE.test(f.email.value.trim()))
                                                      fail(f.email, 'Please enter a valid email');

      if (!f.mobile.value.trim())                     fail(f.mobile, 'Please enter your mobile number');
      else if (!phoneRE.test(f.mobile.value.trim()))  fail(f.mobile, 'Please enter a valid mobile number');

      if (!f.config.value)                            fail(f.config, 'Please choose the home you’re interested in');

      const dv = f.visit_date.value.trim();
      if (!dv)                                        fail(f.visit_date, 'Please pick a preferred visit date');
      else if (!/^\d{4}-\d{2}-\d{2}$/.test(dv))       fail(f.visit_date, 'Please pick a valid date');
      else {
        const t = new Date();
        const todayStr = t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-' + String(t.getDate()).padStart(2, '0');
        if (dv < todayStr)                            fail(f.visit_date, 'Please pick today or a future date');
      }

      if (!f.visit_time.value)                        fail(f.visit_time, 'Please choose a preferred time window');

      if (firstBad) { firstBad.focus(); return false; }
      return true;
    }

    form.addEventListener('submit', async e => {
      e.preventDefault();
      if (!validate()) return;

      // --- Anti-spam #1: honeypot. The hidden "_honey" field is invisible to
      // humans; only bots fill it. If it has a value, drop silently (show the
      // usual thank-you so the bot can't tell it was blocked) and never send.
      if (f._honey && f._honey.value.trim()) {
        $('#formOk').innerHTML = '<i class="fa fa-check-circle"></i> Thank you! Our team will call you shortly.';
        $('#formOk').style.background = '';
        $('#formOk').classList.add('show');
        form.reset();
        setTimeout(() => $('#formOk').classList.remove('show'), 6000);
        return;
      }
      // --- Anti-spam #2: time-trap. A real person can't fill this form in under
      // 3 seconds; near-instant submits are bots. Soft-block so a genuine user
      // can simply submit again (by then enough time has elapsed).
      if (Date.now() - formLoadedAt < 3000) {
        $('#formOk').innerHTML = '<i class="fa fa-exclamation-circle"></i> Please take a moment, then try again.';
        $('#formOk').style.background = 'var(--red)';
        $('#formOk').classList.add('show');
        setTimeout(() => $('#formOk').classList.remove('show'), 4000);
        return;
      }

      const submitBtn = form.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Sending...';
      submitBtn.disabled = true;

      try {
        // Posts the enquiry to send-lead.php (shared hardened handler).
        const res = await fetch('send-lead.php', {
          method: 'POST',
          headers: { 'Accept': 'application/json' },
          body: new FormData(form)
        });
        const data = await res.json();

        if (data.ok === true) {
          $('#formOk').innerHTML = '<i class="fa fa-check-circle"></i> Thank you! Our team will call you shortly.';
          $('#formOk').style.background = '';
          $('#formOk').classList.add('show');
          form.reset();
        } else {
          throw new Error(data.message || 'Submission failed');
        }
      } catch (err) {
        $('#formOk').innerHTML = '<i class="fa fa-exclamation-circle"></i> Sorry, something went wrong. Please call 044 4000 5000.';
        $('#formOk').style.background = 'var(--red)';
        $('#formOk').classList.add('show');
      }

      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
      setTimeout(() => $('#formOk').classList.remove('show'), 6000);
    });
  }

  /* ---------- 11b. Feedback form (inline per-field errors + anti-spam) --- */
  const fbForm = $('#feedbackForm');
  if (fbForm) {
    const emailRE = /^([a-zA-Z0-9_.\-])+@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    const phoneRE = /^((\+)?[1-9]{1,2})?([-\s.])?((\(\d{1,4}\))|\d{1,4})(([-\s.])?[0-9]{1,12}){1,2}$/;
    const f = fbForm.elements;
    const formLoadedAt = Date.now();

    const fieldOf = el => el && el.closest('.field');
    const clearErr = el => { const fl = fieldOf(el); if (fl) fl.classList.remove('invalid'); };
    const showErr  = (el, msg) => {
      const fl = fieldOf(el); if (!fl) return;
      fl.classList.add('invalid');
      const box = fl.querySelector('.field__err'); if (box) box.textContent = msg;
    };

    fbForm.querySelectorAll('input, select, textarea').forEach(el => {
      el.addEventListener('input',  () => clearErr(el));
      el.addEventListener('change', () => clearErr(el));
    });

    function validate() {
      let firstBad = null;
      const fail = (el, msg) => { showErr(el, msg); if (!firstBad) firstBad = el; };
      fbForm.querySelectorAll('.field').forEach(fl => fl.classList.remove('invalid'));

      if (!f.name.value.trim())                       fail(f.name, 'Please enter your name');

      if (!f.mobile.value.trim())                     fail(f.mobile, 'Please enter your mobile number');
      else if (!phoneRE.test(f.mobile.value.trim()))  fail(f.mobile, 'Please enter a valid mobile number');

      // Email is optional — only validate the format when something was typed.
      if (f.email.value.trim() && !emailRE.test(f.email.value.trim()))
                                                      fail(f.email, 'Please enter a valid email');

      if (!f.message.value.trim())                    fail(f.message, 'Please share your feedback');

      if (firstBad) { firstBad.focus(); return false; }
      return true;
    }

    fbForm.addEventListener('submit', async e => {
      e.preventDefault();
      if (!validate()) return;

      // Anti-spam: honeypot (silent drop) + time-trap (soft block).
      if (f._honey && f._honey.value.trim()) {
        $('#formOk').innerHTML = '<i class="fa fa-check-circle"></i> Thank you for your feedback! Our team will review it shortly.';
        $('#formOk').style.background = '';
        $('#formOk').classList.add('show');
        fbForm.reset();
        setTimeout(() => $('#formOk').classList.remove('show'), 6000);
        return;
      }
      if (Date.now() - formLoadedAt < 3000) {
        $('#formOk').innerHTML = '<i class="fa fa-exclamation-circle"></i> Please take a moment, then try again.';
        $('#formOk').style.background = 'var(--red)';
        $('#formOk').classList.add('show');
        setTimeout(() => $('#formOk').classList.remove('show'), 4000);
        return;
      }

      const submitBtn = fbForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Sending...';
      submitBtn.disabled = true;

      try {
        const res = await fetch('send-lead.php', {
          method: 'POST',
          headers: { 'Accept': 'application/json' },
          body: new FormData(fbForm)
        });
        const data = await res.json();
        if (data.ok === true) {
          $('#formOk').innerHTML = '<i class="fa fa-check-circle"></i> Thank you for your feedback! Our team will review it shortly.';
          $('#formOk').style.background = '';
          $('#formOk').classList.add('show');
          fbForm.reset();
        } else {
          throw new Error(data.message || 'Submission failed');
        }
      } catch (err) {
        $('#formOk').innerHTML = '<i class="fa fa-exclamation-circle"></i> Sorry, something went wrong. Please call 044 4000 5000.';
        $('#formOk').style.background = 'var(--red)';
        $('#formOk').classList.add('show');
      }

      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
      setTimeout(() => $('#formOk').classList.remove('show'), 6000);
    });
  }

  /* ---------- 12. Footer year -------------------------------------- */
  const yearEl = $('#year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();
})();
