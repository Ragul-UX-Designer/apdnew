<?php
/**
 * Amarprakash — Temple Waves lead handler.
 * Thin shim: delegates to the shared, hardened handler at the site root so every
 * site uses the same `send-lead.php` filename with zero logic/secret duplication.
 */
require __DIR__ . '/../../send-lead.php';
